function attachEvents() {
  let tbody = document.querySelector('#results tbody');

  let inputFirsName = document.querySelector('input[name="firstName"]');
  let inputLastName = document.querySelector('input[name="lastName"]');
  let inputFacultyNumber = document.querySelector('input[name="facultyNumber"]');
  let inputGrade = document.querySelector('input[name="grade"]');
  
  window.addEventListener("load", () => {
    
    fetch(`http://localhost:3030/jsonstore/collections/students`).then(response => {
      return response.json();
    }).then(students => {
      //{firstName, lastName, facultyNumber, grade: 4.99 THE GRADE IS INT
      //const [firstName, lastName, facultyNumber, grade]  = Object.entries(students);

      for (const student of Object.entries(students)) {
        //const objProps  = student[1];
        const [firstName, lastName, facultyNumber, grade]  = Object.entries(student[1]);
        
        let tr = document.createElement('tr');
        let tdFirstName = document.createElement('td');
        let tdlastName = document.createElement('td');
        let tdfacultyNumber = document.createElement('td');
        let tdgrade = document.createElement('td');

        tdFirstName.textContent = firstName[1];
        tdlastName.textContent = lastName[1];
        tdfacultyNumber.textContent = facultyNumber[1];
        tdgrade.textContent = grade[1];

        tr.appendChild(tdFirstName); 
        tr.appendChild(tdlastName);
        tr.appendChild(tdfacultyNumber);
        tr.appendChild(tdgrade);

        tbody.appendChild(tr);
      }
    })
  });
  
  document.getElementById('submit').addEventListener('click', () =>{

    let student = {
      firstName: inputFirsName.value,
      lastName: inputLastName.value,
      facultyNumber: inputFacultyNumber.value,
      grade: inputGrade.value
    };


    fetch(`http://localhost:3030/jsonstore/collections/students`, {
      method: 'POST',
      body: JSON.stringify(student)
    })
  });

}

attachEvents();